import numpy as np
import pandas as pd
from pandas import *
from openpyxl import load_workbook
from bs4 import BeautifulSoup
from urllib.request import urlopen,Request



wb = load_workbook(filename= 'dndspeakindex.xlsx')
ws = wb["Sheet1"]

links = []
for x in ws.iter_cols():
    for cell in x:
        links.append(cell.hyperlink.display)

req = Request(
    url=links[1], 
    headers={'User-Agent': 'Mozilla/5.0'}
)
webpage = urlopen(req).read()
soup = BeautifulSoup(webpage,'lxml')
x = soup.body.table.find('tbody').find_all("tr")

l = []
for row in x:
    l.append(row.find(class_='column-2').text)

print(l)
